/**
 * @author Almas Baimagambetov (almaslvl@gmail.com)
 */
open module pacman.main {
    requires com.almasb.fxgl.all;
}