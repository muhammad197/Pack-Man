package Modle;

public enum Level {
	 easy, medium, hard, superhard; 
}
