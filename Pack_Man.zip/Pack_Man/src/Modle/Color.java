package Modle;

public enum Color {
red,blue,yellow;
}
