package Modle;

public class BombPoints extends PeckPoints {

	public BombPoints(int id, String image) {
		super(id, image);
		// TODO Auto-generated constructor stub
	}

	

}
